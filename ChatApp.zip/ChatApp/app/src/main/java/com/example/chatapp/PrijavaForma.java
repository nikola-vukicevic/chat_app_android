package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.firebase.ui.auth.AuthUI;
import com.firebase.ui.auth.IdpResponse;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PrijavaForma extends AppCompatActivity {
    public static final String BAZA_IME = "korisnik.db";

    private static  int       RC_SIGN_IN = 100;
    private Button            PrijavaDugme;
    private DatabaseReference DBR_KORISNICI;
    private List<Korisnik>    SpisakKorisnika;
    private List<String>      KorisnikIzBaze;
    private Korisnik          KORISNIK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prijava_forma);

        // NAS KOD:

        Inicijalizacija();
    }

    private void Inicijalizacija() {
        setTitle("Prijava Korisnika");
        Intent PrenetiNalog = getIntent();
        if(PrenetiNalog != null){
            Boolean pokrenutiOdjavu = PrenetiNalog.getBooleanExtra("ODJAVA_NALOG", false);
            if(pokrenutiOdjavu){
                GoogleOdjava();
            }
        }

        PrijavaDugme    = (Button) findViewById(R.id.prijavaDugmePrijava);
        DBR_KORISNICI   = FirebaseDatabase.getInstance().getReference().child("korisnici");
        KORISNIK        = null;
        SpisakKorisnika = null;
        KorisnikIzBaze  = null;

        PrijavaDugme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GooglePrijava();
            }
        });

        DBR_KORISNICI.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                SpisakKorisnika = CitanjeKorisnikaIzBaze(snapshot);
                ProveraBaze();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    protected void ProveraBaze(){
        BazaPristup BP1 = new BazaPristup(getApplicationContext(), BAZA_IME, null, 1);

        if(BP1.PostojiZapamcenaPozicija(getApplicationContext(), BAZA_IME)) {
            KorisnikIzBaze  = BP1.CitanjeCeleBaze();

            if(KorisnikIzBaze != null) {
                KORISNIK = PretragaKorisnika(KorisnikIzBaze.get(1), SpisakKorisnika);
                if(KORISNIK != null && KORISNIK.citanjePrivilegije().equals("DA")) {
                    String s = "AUTOMATSKA PRIJAVA:\nPrijavljeni ste kao: " + KORISNIK.citanjeKorisnicko_ime();
                    s       += "\n(" + KORISNIK.citanjeEmail() + ")";
                    Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
                    Intent i = new Intent(getApplicationContext(), MainActivity.class);
                    i.putExtra("KORISNIK_KORISNICKO_IME", KORISNIK.citanjeKorisnicko_ime());
                    i.putExtra("KORISNIK_AVATAR",         KORISNIK.citanjeAvatar());
                    i.putExtra("KORISNIK_GOOGLE_ID",      KORISNIK.citanjeStringId());
                    i.putExtra("KORISNIK_EMAIL",          KORISNIK.citanjeEmail());
                    i.putExtra("KORISNIK_PRIVILEGIJE",    KORISNIK.citanjePrivilegije());
                    i.putExtra("KORISNIK_TOKEN",          KORISNIK.citanjeToken());
                    startActivity(i);
                }
                else{
                    Toast.makeText(getApplicationContext(), "Poštovani, nažalost, izgubili ste privilegije za pristup chat aplikaciji!", Toast.LENGTH_LONG).show();
                    return;
                }
            }
            else{
                Toast.makeText(getApplicationContext(), "Molimo prijavite se u chat aplikaciju preko Vašeg Google naloga", Toast.LENGTH_LONG).show();
                return;
            }
        }
        else {
            Toast.makeText(getApplicationContext(), "Molimo prijavite se u chat aplikaciju preko Vašeg Google naloga", Toast.LENGTH_LONG).show();
            BP1.GenerisanjeTabele();
            return;
        }
    }

    private void GoogleOdjava(){
        FirebaseAuth.getInstance().signOut();
        BazaPristup BP1 = new BazaPristup(getApplicationContext(), BAZA_IME, null, 1);
        BP1.UpisUBazu("", "", "", "", "", "");
    }

    private void GooglePrijava() {
        List<AuthUI.IdpConfig> providers = Arrays.asList(
            new AuthUI.IdpConfig.GoogleBuilder().build());

        startActivityForResult(AuthUI.getInstance().createSignInIntentBuilder().setAvailableProviders(providers).build(), RC_SIGN_IN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            IdpResponse response = IdpResponse.fromResultIntent(data);

            if (resultCode == RESULT_OK) {
                FirebaseUser GoogleNalog = FirebaseAuth.getInstance().getCurrentUser();
                KORISNIK = PretragaKorisnika(GoogleNalog.getUid(), SpisakKorisnika);

                if(KORISNIK == null) {
                    String noviId        = GoogleNalog.getUid();
                    String korisnickoIme = GoogleNalog.getDisplayName();
                    String ime           = korisnickoIme.substring(0, korisnickoIme.indexOf(" "));
                    String prezime       = korisnickoIme.substring(korisnickoIme.indexOf(" ") + 1, korisnickoIme.length());
                    String email         = GoogleNalog.getEmail();
                    String avatar        = GoogleNalog.getPhotoUrl().toString();
                    KORISNIK             = new Korisnik(noviId, ime, prezime, korisnickoIme, email, avatar, "DA");
                    KORISNIK.DodavanjeUBazu(DBR_KORISNICI);
                }

                if(KORISNIK.citanjePrivilegije().equals("DA")) {
                    String s = "Prijavljeni ste kao:\n" + KORISNIK.citanjeKorisnicko_ime();
                    s       += "\n(" + KORISNIK.citanjeEmail() + ")";
                    Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
                    Intent i = new Intent(getApplicationContext(), MainActivity.class);
                    i.putExtra("KORISNIK_KORISNICKO_IME", KORISNIK.citanjeKorisnicko_ime());
                    i.putExtra("KORISNIK_AVATAR",         KORISNIK.citanjeAvatar());
                    i.putExtra("KORISNIK_GOOGLE_ID",      KORISNIK.citanjeStringId());
                    i.putExtra("KORISNIK_EMAIL",          KORISNIK.citanjeEmail());
                    i.putExtra("KORISNIK_PRIVILEGIJE",    KORISNIK.citanjePrivilegije());
                    i.putExtra("KORISNIK_TOKEN",          KORISNIK.citanjeToken());
                    startActivity(i);
                }
                else{
                    Toast.makeText(getApplicationContext(), "Poštovani, nažalost, izgubili ste privilegije za pristup chat aplikaciji!", Toast.LENGTH_LONG).show();
                    return;
                }
            }
            else {
                Toast.makeText(getApplicationContext(), "Propade pokušaj prijave - nema chat-a za Vas!", Toast.LENGTH_LONG).show();
            }
        }
    }

    private Korisnik PretragaKorisnika(String ajDi, List<Korisnik> spisakKorisnika){
        for(int i = 0; i < spisakKorisnika.size(); i++){
            if(spisakKorisnika.get(i).citanjeStringId().equals(ajDi)){
                return spisakKorisnika.get(i);
            }
        }

        return null;
    }

    private List<Korisnik> CitanjeKorisnikaIzBaze(DataSnapshot slogovi){
        List<Korisnik> spisakKorisnika = new ArrayList<>();

        for(DataSnapshot slog : slogovi.getChildren()){
            String korisnickoIme  = slog.child("korisnickoIme").getValue(String.class);
            String avatar         = slog.child("avatar").getValue(String.class);
            String imaPrivilegije = slog.child("imaPrivilegije").getValue(String.class);
            String email          = slog.child("email").getValue(String.class);
            String ime            = slog.child("ime").getValue(String.class);
            String prezime        = slog.child("prezime").getValue(String.class);
            Korisnik korisnik     = new Korisnik(slog.getKey(), ime, prezime, korisnickoIme, email, avatar, imaPrivilegije, "");
            spisakKorisnika.add(korisnik);
        }

        return spisakKorisnika;
    }
}