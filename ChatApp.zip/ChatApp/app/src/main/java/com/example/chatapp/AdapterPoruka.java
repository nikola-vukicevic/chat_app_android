package com.example.chatapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.List;

public class AdapterPoruka extends RecyclerView.Adapter<AdapterPoruka.Pridrzavac> {
    private List<Poruka> Poruke;
    private Context      context;

    public AdapterPoruka(Context context, List<Poruka> poruke) {
        this.context = context;
        this.Poruke  = poruke;
        //Toast.makeText(context, String.format("%d", Poruke.size()), Toast.LENGTH_LONG).show();
    }

    @NonNull
    @Override
    public Pridrzavac onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View           view     = inflater.inflate(R.layout.chat_poruka, parent, false);
        return new Pridrzavac(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Pridrzavac holder, int position) {
        holder.chatPorukaKorisnickoIme.setText(Poruke.get(position).citanjeKorisnickoIme());
        holder.chatPorukaInfo.setText(Poruke.get(position).citanjeVreme());
        holder.chatPorukaTekstPoruke.setText(Poruke.get(position).citanjeTekstProuke());
        Picasso.get().load(Poruke.get(position).citanjeAvatar()).into(holder.chatPorukaAvatar);
    }

    @Override
    public int getItemCount() {
        return Poruke.size();
    }

    public class Pridrzavac extends RecyclerView.ViewHolder{
        private TextView  chatPorukaKorisnickoIme,
                          chatPorukaInfo,
                          chatPorukaTekstPoruke;
        private ImageView chatPorukaAvatar;

        public Pridrzavac(@NonNull View itemView) {
            super(itemView);
            chatPorukaKorisnickoIme = itemView.findViewById(R.id.chatPorukaKorisnickoIme);
            chatPorukaInfo          = itemView.findViewById(R.id.chatPorukaInfo);
            chatPorukaTekstPoruke   = itemView.findViewById(R.id.chatPorukaTekstPoruke);
            chatPorukaAvatar        = itemView.findViewById(R.id.chatPorukaAvatar);
        }
    }
}
