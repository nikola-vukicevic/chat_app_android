package com.example.chatapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.ui.auth.AuthUI;
import com.firebase.ui.auth.IdpResponse;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static final String TABELA_PORUKE = "poruke";
    public static final String  BAZA_IME     = "korisnik.db";

    private Button              dugmeSlanje;
    private EditText            poljePoruka;
    private RecyclerView        tabelaPoruke;
    private DatabaseReference   DBR,
                                DBR_PORUKE;
    private List<Poruka>        SpisakPoruka;
    private AdapterPoruka       AdapterPoruke;

    private String              KORISNIK_GOOGLE_ID,
                                KORISNIK_KORISNICKO_IME,
                                KORISNIK_AVATAR,
                                KORISNIK_EMAIL,
                                KORISNIK_PRIVILEGIJE,
                                KORISNIK_TOKEN;

    private int                 TABELA_SKROL = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // NASE FUNKCIJE:

        Inicijalizacija();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.app_menu, menu);
        return true;
    }

    private void PokretanjeOdjave(){
        Intent i = new Intent(getApplicationContext(), PrijavaForma.class);
        i.putExtra("ODJAVA_NALOG", true);
        startActivity(i);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.meni_odjava: PokretanjeOdjave(); return true;
            default: return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed()
    {
        this.moveTaskToBack(true);
    }

    private List<Poruka> CitanjePorukaIzBaze(DataSnapshot slogovi){
        List<Poruka> spisakPoruka = new ArrayList<>();

        for(DataSnapshot slog : slogovi.getChildren()){
            String korisnickoIme = slog.child("korisnickoIme").getValue(String.class);
            String avatar        = slog.child("avatar").getValue(String.class);
            String tekstPoruke   = slog.child("tekstPoruke").getValue(String.class);
            String vreme         = slog.child("vreme").getValue(String.class);
            Poruka poruka        = new Poruka(Long.parseLong(slog.getKey()), korisnickoIme, avatar, tekstPoruke);
            spisakPoruka.add(poruka);
        }

        return spisakPoruka;
    }

    private void Inicijalizacija(){
        dugmeSlanje  = (Button)       findViewById(R.id.dugmeSlanje);
        poljePoruka  = (EditText)     findViewById(R.id.poljePoruka);
        tabelaPoruke = (RecyclerView) findViewById(R.id.tabelaPoruke);
        DBR          = FirebaseDatabase.getInstance().getReference();
        DBR_PORUKE   = FirebaseDatabase.getInstance().getReference().child("poruke");

        // INTENT

        Intent prenosIzFormePrijava = getIntent();
        KORISNIK_KORISNICKO_IME     = prenosIzFormePrijava.getStringExtra("KORISNIK_KORISNICKO_IME");
        KORISNIK_AVATAR             = prenosIzFormePrijava.getStringExtra("KORISNIK_AVATAR");
        KORISNIK_GOOGLE_ID          = prenosIzFormePrijava.getStringExtra("KORISNIK_GOOGLE_ID");
        KORISNIK_EMAIL              = prenosIzFormePrijava.getStringExtra("KORISNIK_EMAIL");
        KORISNIK_PRIVILEGIJE        = prenosIzFormePrijava.getStringExtra("KORISNIK_PRIVILEGIJE");
        KORISNIK_TOKEN              = prenosIzFormePrijava.getStringExtra("KORISNIK_TOKEN");

        // BAZA

        BazaPristup BP1 = new BazaPristup(getApplicationContext(), BAZA_IME, null, 1);

        if(!BP1.PostojiZapamcenaPozicija(getApplicationContext(), BAZA_IME)) {
            BP1.GenerisanjeTabele();
        }

        BP1.UpisUBazu(KORISNIK_GOOGLE_ID, KORISNIK_KORISNICKO_IME, KORISNIK_EMAIL, KORISNIK_AVATAR, KORISNIK_PRIVILEGIJE, KORISNIK_TOKEN);

        // OSTALO

        dugmeSlanje.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // DODAVANJE PORUKA:

                String tekstPoruke = poljePoruka.getText().toString().trim();

                if(tekstPoruke.equals(""))
                {
                    Toast.makeText(getApplicationContext(), "Prosleđivanje praznih poruka nije dozvoljeno.", Toast.LENGTH_LONG).show();
                    poljePoruka.setText("");
                    return;
                }

                long   vremeLong = Calendar.getInstance().getTimeInMillis();

                Poruka P = new Poruka(vremeLong, KORISNIK_KORISNICKO_IME, KORISNIK_AVATAR, tekstPoruke);
                P.DodavanjeUBazu(DBR, TABELA_PORUKE);
                poljePoruka.setText("");
            }
        });

        DBR_PORUKE.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ///*
                SpisakPoruka  = CitanjePorukaIzBaze(dataSnapshot);
                AdapterPoruke = new AdapterPoruka(MainActivity.this, SpisakPoruka);
                tabelaPoruke.setAdapter(AdapterPoruke);
                tabelaPoruke.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                tabelaPoruke.scrollToPosition(SpisakPoruka.size() - 1);
                //*/
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        tabelaPoruke.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View view, int i, int i1, int i2, int i3, int i4, int i5, int i6, int i7) {
                if(i3 < i7) {
                    tabelaPoruke.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            tabelaPoruke.scrollBy(0, 500);// .scrollToPosition(SpisakPoruka.size() - 1);
                        }
                    }, 100);
                }
            }
        });
    }
}
