package com.example.chatapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class BazaPristup extends SQLiteOpenHelper {
    public static final String TABELA_MAZIV  = "korisnik";

    public BazaPristup(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    public List<String> CitanjeCeleBaze(){
        List<String> polja = new ArrayList<>();

        String         upit  = "SELECT * FROM " + TABELA_MAZIV;
        SQLiteDatabase baza  = this.getReadableDatabase();
        Cursor pokazivac     = baza.rawQuery(upit, null);

        if(pokazivac.moveToFirst()){
            int    red            = pokazivac.getInt(0);    polja.add(String.format("%d", red));
            String google_id      = pokazivac.getString(1);

            if(google_id.equals("")) {
                return null;
            }
            else {
                polja.add(google_id);
            }

            String korisnicko_ime = pokazivac.getString(2); polja.add(korisnicko_ime);
            String email          = pokazivac.getString(3); polja.add(email);
            String avatar         = pokazivac.getString(4); polja.add(avatar);
            String privilegije    = pokazivac.getString(5); polja.add(privilegije);
            String token          = pokazivac.getString(6); polja.add(token);
        }

        pokazivac.close();
        baza.close();

        return polja;
    }

    public boolean GenerisanjeTabele(){
        SQLiteDatabase baza = this.getWritableDatabase();
        ContentValues  slog = new ContentValues();

        slog.put("red",            1);
        slog.put("google_id",      "");
        slog.put("korisnicko_ime", "");
        slog.put("email",          "");
        slog.put("avatar",         "");
        slog.put("privilegije",    "");
        slog.put("token",          "");

        long rez = baza.insert(TABELA_MAZIV,null, slog);
        baza.close();
        return rez != -1;
    }

    public Boolean UpisUBazu(Korisnik korisnik){
        SQLiteDatabase baza = this.getWritableDatabase();
        ContentValues slog  = new ContentValues();

        slog.put("google_id",      korisnik.citanjeStringId());
        slog.put("korisnicko_ime", korisnik.citanjeKorisnicko_ime());
        slog.put("email",          korisnik.citanjeEmail());
        slog.put("avatar",         korisnik.citanjeAvatar());
        slog.put("privilegije",    korisnik.citanjePrivilegije());
        slog.put("token",          ""); // DORADITI!!!

        long rez = baza.update(TABELA_MAZIV, slog, "red=1", null);
        baza.close();
        return rez != -1;
    }

    public Boolean UpisUBazu(String google_id, String korisnicko_ime, String email, String avatar,
                             String privilegije, String token){
        SQLiteDatabase baza = this.getWritableDatabase();
        ContentValues slog  = new ContentValues();

        slog.put("google_id",      google_id);
        slog.put("korisnicko_ime", korisnicko_ime);
        slog.put("email",          email);
        slog.put("avatar",         avatar);
        slog.put("privilegije",    privilegije);
        slog.put("token",          ""); // DORADITI!!!

        long rez = baza.update(TABELA_MAZIV, slog, "red=1", null);
        baza.close();
        return rez != -1;
    }

    public Boolean PostojiZapamcenaPozicija(Context context, String ime){
        File dbFile = context.getDatabasePath(ime);
        return dbFile.exists();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String upit = "CREATE TABLE " + TABELA_MAZIV + " (red INTEGER PRIMARY KEY, google_id TEXT, korisnicko_ime TEXT, email TEXT, avatar TEXT, privilegije TEXT, token TEXT); ";
        db.execSQL(upit);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
